from Frontend.GUI import (
    GraphicalUserInterface,
    SetAssistantStatus,
    ShowTextToScreen,
    TempDirectoryPath,
    SetMicrophoneStatus,
    AnswerModifier,
    QueryModifier,
    GetMicrophoneStatus,
    GetAssistantStatus)
from Backend.Model import FirstLayerDMM
from Backend.RealTimeSearchEngine import RealtimeSearchEngine                           
from Backend.Automation import Automation
from Backend.SpeechToText import SpeechRecognition
from Backend.Chatbot import ChatBot
from Backend.TextToSpeech import TextToSpeech
from Backend.LanguageSelector import get_current_language, set_language, get_available_languages
from dotenv import dotenv_values, set_key
from asyncio import run
from time import sleep
import subprocess
import threading
import json
import os

env_vars = dotenv_values(".env")
Username = env_vars.get("Username")
Assistantname = env_vars.get("Assistantname")
DefaultMessage = f'''{Username} : Hello {Assistantname}, How are you?
{Assistantname} : Welcome {Username}. I am doing well. How may i help you?'''
subprocesses = []
Functions = [
    "open", "close", "play", "system", "content", "google search", 
    "youtube search", "set language", "change voice", "generate image",
    "download", "translate", "weather", "calculator", "email",
    "schedule", "take screenshot", "record", "navigate", "find file",
    "summarize", "social media", "shop", "news", "music", "video call",
    "workflow"
]

def ShowDefaultChatIfNoChats():
    File = open(r'Data\ChatLog.json', 'r', encoding='utf-8')
    if len(File.read()) < 5:
        with open(TempDirectoryPath('Database.data'), 'w', encoding='utf-8') as file:
            file.write("")
        with open(TempDirectoryPath('Responses.data'), 'w', encoding='utf-8') as file:
            file.write(DefaultMessage)

def ReadChatLogJson():
    with open(r'Data\ChatLog.json', 'r', encoding='utf-8') as file:
        chatlog_data = json.load(file)
    return chatlog_data

def ChatLogIntegration():
    json_data = ReadChatLogJson()
    formatted_chatlog = ""
    for entry in json_data:
        if entry["role"] == "user":
            formatted_chatlog += f"User: {entry['content']}\n"
        elif entry["role"] == "assistant":
            formatted_chatlog += f"Assistant: {entry['content']}\n"
    formatted_chatlog = formatted_chatlog.replace("User", Username + " ")
    formatted_chatlog = formatted_chatlog.replace("Assistant", Assistantname + " ")

    with open(TempDirectoryPath('Database.data'), 'w', encoding='utf-8') as file:
        file.write(AnswerModifier(formatted_chatlog))

def ShowChatsOnGUI():
    File = open(TempDirectoryPath('Database.data'), 'r', encoding='utf-8')
    Data = File.read()
    if len(str(Data)) > 0:
        lines = Data.split('\n')
        result = '\n'.join(lines)
        File.close()
        File = open(TempDirectoryPath('Responses.data'), 'w', encoding='utf-8')
        File.write(result)
        File.close()

def InitialExecution():
    SetMicrophoneStatus("False")
    ShowTextToScreen("")
    ShowDefaultChatIfNoChats()
    ChatLogIntegration()
    ShowChatsOnGUI()

InitialExecution()

def CheckImageGenerationStatus():
    """
    Check if images were generated and notify the user
    """
    with open(r"Frontend\Files\ImageGeneration.data", "r") as f:
        try:
            Data = f.read().strip()
            if Data == "False,False":
                # Images have been generated or process finished
                SetAssistantStatus("Images have been generated!")
                
                # Get current language
                current_lang = get_current_language()
                
                # Provide feedback in the current language
                if current_lang["language"] == "Bengali":
                    message = "ছবিগুলি তৈরি করা হয়েছে এবং আপনার স্ক্রিনে প্রদর্শিত হওয়া উচিত।"
                else:
                    message = "The images have been generated and should be displayed on your screen."
                
                ShowTextToScreen(f"{Assistantname} : {message}")
                TextToSpeech(message)
                return True
        except Exception as e:
            print(f"Error checking image generation status: {e}")
    return False

def MainExecution():
    TaskExecution = False
    ImageExecution = False
    ImageGenerationQuery = ""

    SetAssistantStatus("Listening ...")
    Query = SpeechRecognition()
    ShowTextToScreen(f"{Username} : {Query}")
    SetAssistantStatus("Thinking ...")
    Decision = FirstLayerDMM(Query)

    print("")
    print(f"Decision : {Decision}")
    print("")

    # Check if previous image generation has completed
    CheckImageGenerationStatus()

    # Special handling for Bengali image generation requests
    if "ছবি" in Query.lower() or "চিত্র" in Query.lower() or "ফটো" in Query.lower():
        if "তৈরি" in Query.lower() or "দেখাও" in Query.lower() or "জেনেরেট" in Query.lower():
            print("Bengali image request detected")
            ImageGenerationQuery = Query
            ImageExecution = True
            
            # Get current language
            current_lang = get_current_language()
            
            # Provide feedback in Bengali
            response = f"আমি আপনার অনুরোধের উপর ভিত্তি করে ছবি তৈরি করব: {Query}"
            ShowTextToScreen(f"{Assistantname} : {response}")
            SetAssistantStatus("ছবি তৈরি করছি...")
            TextToSpeech(response)

    # Standard check for image generation requests in decision
    if not ImageExecution:
        for queries in Decision:
            if "generate" in queries.lower() and ("image" in queries.lower() or "picture" in queries.lower() or "photo" in queries.lower()):
                ImageGenerationQuery = queries
                ImageExecution = True
                
                # Get current language
                current_lang = get_current_language()
                
                # Provide feedback in the current language
                if current_lang["language"] == "Bengali":
                    response = f"আমি আপনার অনুরোধের উপর ভিত্তি করে ছবি তৈরি করব: {queries}"
                else:
                    response = f"I'll generate images based on your request: {queries}"
                    
                ShowTextToScreen(f"{Assistantname} : {response}")
                SetAssistantStatus("Generating images...")
                TextToSpeech(response)
                break

    # Check for general and realtime queries
    G = any([i for i in Decision if i.startswith("general")])
    R = any([i for i in Decision if i.startswith("realtime")])
    Mearged_query = " ".join(
        [" ".join(i.split()[1:]) for i in Decision if i.startswith("general") or i.startswith("realtime")]
    )
    
    # Handle voice changing (Bengali voices)
    for queries in Decision:
        if queries.startswith("change voice"):
            voice_requested = queries.replace("change voice ", "").strip().lower()
            
            # Handle Bengali voice changes
            if "male" in voice_requested or "pradeep" in voice_requested:
                SetAssistantStatus(f"Changing to male Bengali voice...")
                voice = "bn-BD-PradeepNeural"
                set_key(".env", "AssistantVoice", voice)
                response = "I've changed to the male Bengali voice."
            
            elif "female" in voice_requested or "nabanita" in voice_requested:
                SetAssistantStatus(f"Changing to female Bengali voice...")
                voice = "bn-BD-NabanitaNeural"
                set_key(".env", "AssistantVoice", voice)
                response = "I've changed to the female Bengali voice."
            
            elif "bashkar" in voice_requested or "indian male" in voice_requested:
                SetAssistantStatus(f"Changing to Indian male Bengali voice...")
                voice = "bn-IN-BashkarNeural"
                set_key(".env", "AssistantVoice", voice)
                response = "I've changed to the Indian male Bengali voice."
            
            elif "tanishaa" in voice_requested or "indian female" in voice_requested:
                SetAssistantStatus(f"Changing to Indian female Bengali voice...")
                voice = "bn-IN-TanishaaNeural"
                set_key(".env", "AssistantVoice", voice)
                response = "I've changed to the Indian female Bengali voice."
            
            else:
                # List available voices for the current language
                current_lang = get_current_language()
                languages = get_available_languages()
                
                if current_lang["language"] in languages:
                    lang_details = languages[current_lang["language"]]
                    main_voice = lang_details["voice"]
                    alt_voices = lang_details["alt_voices"]
                    
                    response = f"Available voices for {current_lang['language']}:\n"
                    response += f"- Main voice: {main_voice}\n"
                    response += "- Alternative voices:\n"
                    for voice in alt_voices:
                        response += f"  - {voice}\n"
                else:
                    response = "I couldn't find information about available voices for the current language."
            
            ShowTextToScreen(f"{Assistantname} : {response}")
            SetAssistantStatus("Answering ...")
            TextToSpeech(response)
            TaskExecution = True
            return True
    
    # Handle language switching
    for queries in Decision:
        if queries.startswith("set language"):
            language_requested = queries.replace("set language ", "").strip().title()
            available_langs = get_available_languages()
            
            if language_requested in available_langs:
                SetAssistantStatus(f"Switching to {language_requested}...")
                success = set_language(language_requested)
                
                if success:
                    current_lang = get_current_language()
                    response = f"Language has been changed to {language_requested}."
                    ShowTextToScreen(f"{Assistantname} : {response}")
                    SetAssistantStatus("Answering ...")
                    TextToSpeech(response)
                else:
                    response = f"Failed to change language to {language_requested}."
                    ShowTextToScreen(f"{Assistantname} : {response}")
                    SetAssistantStatus("Answering ...")
                    TextToSpeech(response)
                
                TaskExecution = True
                return True
            else:
                languages_list = ", ".join(available_langs.keys())
                response = f"Language {language_requested} is not supported. Available languages: {languages_list}."
                ShowTextToScreen(f"{Assistantname} : {response}")
                SetAssistantStatus("Answering ...")
                TextToSpeech(response)
                TaskExecution = True
                return True
    
    # Handle automation tasks (open, close, play, etc.)
    automation_tasks = [query for query in Decision if not query.startswith("general") and not query.startswith("realtime")]
    if automation_tasks:
        try:
            SetAssistantStatus("Executing task...")
            run(Automation(automation_tasks))
            
            # Provide confirmation for completed tasks
            task_types = []
            for task in automation_tasks:
                if " " in task:
                    task_type = task.split()[0]
                else:
                    task_type = task
                task_types.append(task_type)
            
            # Ensure task_types is not empty before joining
            if task_types:
                task_summary = ", ".join(set(task_types))
                response = f"I've completed the {task_summary} tasks you requested."
            else:
                response = "I've completed the tasks you requested."
            
            ShowTextToScreen(f"{Assistantname} : {response}")
            SetAssistantStatus("Task completed")
            TextToSpeech(response)
            TaskExecution = True
        except Exception as e:
            print(f"Automation error: {str(e)}")  # Add debugging output
            error_msg = f"Sorry, I encountered an error while executing your request: {str(e)}"
            ShowTextToScreen(f"{Assistantname} : {error_msg}")
            SetAssistantStatus("Error")
            TextToSpeech(error_msg)
            TaskExecution = True
    
    # Handle general and realtime queries if present and no other tasks executed
    if (G or R) and not TaskExecution:
        if G and not R:
            # Only general queries
            SetAssistantStatus("Processing your question...")
            response = ChatBot(Mearged_query)
            ShowTextToScreen(f"{Assistantname} : {response}")
            SetAssistantStatus("Answering...")
            TextToSpeech(response)
            TaskExecution = True
        elif R:
            # Realtime queries (may also include general)
            SetAssistantStatus("Searching for real-time information...")
            response = RealtimeSearchEngine(Mearged_query)
            ShowTextToScreen(f"{Assistantname} : {response}")
            SetAssistantStatus("Answering...")
            TextToSpeech(response)
            TaskExecution = True
    
    return TaskExecution

def FirstThread():
    while True:
        
        CurrentStatus = GetMicrophoneStatus()
       
        if CurrentStatus == "True":
            MainExecution()
        else:
            AIStatus = GetAssistantStatus()
            if "Available ..." in AIStatus:
                sleep(0.1)
            else:
                SetAssistantStatus("Available ...")

def SecondThread():
    GraphicalUserInterface()

if __name__ == "__main__":
    thread2 = threading.Thread(target=FirstThread, daemon=True)
    thread2.start()
    SecondThread()