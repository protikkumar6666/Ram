import os
from dotenv import load_dotenv, dotenv_values, set_key

def get_available_languages():
    """
    Returns a dictionary of available languages and their voice options
    """
    # List of supported languages with their codes and available voices
    return {
        "Bengali": {
            "code": "bn-BD",
            "voice": "bn-BD-NabanitaNeural",
            "alt_voices": ["bn-BD-PradeepNeural", "bn-IN-TanishaaNeural", "bn-IN-BashkarNeural"]
        },
        "English": {
            "code": "en",
            "voice": "en-CA-LiamNeural",
            "alt_voices": ["en-US-JaneNeural", "en-GB-RyanNeural", "en-AU-NatashaNeural"]
        },
        "Hindi": {
            "code": "hi-IN",
            "voice": "hi-IN-SwaraNeural",
            "alt_voices": ["hi-IN-MadhurNeural"]
        }
    }

def get_current_language():
    """
    Returns the current language settings from the .env file
    """
    env_vars = dotenv_values(".env")
    input_lang = env_vars.get("InputLanguage")
    assistant_voice = env_vars.get("AssistantVoice")
    
    # Determine which language is currently set
    available_langs = get_available_languages()
    current_lang = "English"  # Default
    
    for lang, details in available_langs.items():
        if details["code"] == input_lang:
            current_lang = lang
            break
    
    return {
        "language": current_lang,
        "input_code": input_lang,
        "voice": assistant_voice
    }

def set_language(language):
    """
    Sets the language in the .env file
    
    Args:
        language (str): The language name to set (e.g., "Bengali", "English")
    
    Returns:
        bool: True if successful, False otherwise
    """
    try:
        available_langs = get_available_languages()
        
        if language not in available_langs:
            print(f"Language '{language}' not found in available languages")
            return False
        
        # Load the current .env file
        env_path = ".env"
        load_dotenv(env_path)
        
        # Set the new language values
        lang_details = available_langs[language]
        set_key(env_path, "InputLanguage", lang_details["code"])
        set_key(env_path, "AssistantVoice", lang_details["voice"])
        
        # Create a test file to verify the voice works
        try_voice_synthesis(lang_details["voice"], language)
        
        print(f"Language set to {language} ({lang_details['code']})")
        print(f"Assistant voice set to {lang_details['voice']}")
        
        # Update the Voice.html file
        update_voice_html(lang_details["code"])
        
        return True
    
    except Exception as e:
        print(f"Error setting language: {e}")
        return False

def try_voice_synthesis(voice, language):
    """
    Creates a test file to verify that voice synthesis works
    
    Args:
        voice (str): The voice to test
        language (str): The language name
    """
    try:
        import asyncio
        import edge_tts
        
        # Sample text in different languages
        test_texts = {
            "Bengali": "আমি বাংলায় কথা বলতে পারি। আপনি কেমন আছেন?",
            "English": "I can speak in English. How are you?",
            "Hindi": "मैं हिंदी में बात कर सकता हूँ। आप कैसे हैं?"
        }
        
        # Default text if language not found
        test_text = test_texts.get(language, "This is a test.")
        
        # Create a file to test voice synthesis
        async def test_voice():
            file_path = r"Data\voice_test.mp3"
            communicate = edge_tts.Communicate(test_text, voice, pitch='+0Hz', rate='+0%')
            await communicate.save(file_path)
            print(f"Test voice file created at {file_path}")
        
        # Run the test
        asyncio.run(test_voice())
        
    except Exception as e:
        print(f"Error testing voice synthesis: {e}")

def update_voice_html(lang_code):
    """
    Updates the Voice.html file with the new language code
    
    Args:
        lang_code (str): The language code to set
    """
    try:
        html_path = "Data/Voice.html"
        
        # Read the current file
        with open(html_path, "r", encoding="utf-8") as file:
            content = file.read()
        
        # Replace the language code
        content = content.replace('recognition.lang = \'bn-BD\';', f'recognition.lang = \'{lang_code}\';')
        content = content.replace('recognition.lang = \'en\';', f'recognition.lang = \'{lang_code}\';')
        
        # Update the HTML lang attribute
        for lang in ['en', 'bn', 'hi']:
            content = content.replace(f'<html lang="{lang}">', f'<html lang="{lang_code.split("-")[0]}">')
        
        # Update the title based on language
        if lang_code.startswith("bn"):
            title = "বাংলা ভাষা শনাক্তকরণ"
        elif lang_code.startswith("hi"):
            title = "हिंदी भाषा पहचान"
        else:
            title = "Speech Recognition"
            
        # Replace the title
        content = content.replace('<h1>বাংলা ভাষা শনাক্তকরণ</h1>', f'<h1>{title}</h1>')
        content = content.replace('<h1>हिंदी भाषा पहचान</h1>', f'<h1>{title}</h1>')
        content = content.replace('<h1>Speech Recognition</h1>', f'<h1>{title}</h1>')
        
        # Write the updated content
        with open(html_path, "w", encoding="utf-8") as file:
            file.write(content)
        
        print(f"Updated Voice.html with language code: {lang_code}")
    
    except Exception as e:
        print(f"Error updating Voice.html: {e}")

if __name__ == "__main__":
    # Example usage
    current = get_current_language()
    print(f"Current language: {current['language']} ({current['input_code']})")
    print(f"Current voice: {current['voice']}")
    
    # List available languages
    print("\nAvailable languages:")
    for lang, details in get_available_languages().items():
        print(f"- {lang} ({details['code']}): {details['voice']}")
    
    # Set a language from command line if provided
    import sys
    if len(sys.argv) > 1:
        new_lang = sys.argv[1]
        set_language(new_lang) 