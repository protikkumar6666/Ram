import asyncio
import edge_tts
import os

async def list_voices():
    """List all available voices in the Edge TTS API"""
    try:
        voices = await edge_tts.list_voices()
        return voices
    except Exception as e:
        print(f"Error listing voices: {e}")
        return []

async def filter_bengali_voices(voices):
    """Filter and return only Bengali voices"""
    bengali_voices = [voice for voice in voices if 'bn-' in voice["ShortName"]]
    return bengali_voices

async def test_voice(voice_name, text, output_file):
    """Test a specific voice by generating audio"""
    try:
        communicate = edge_tts.Communicate(text, voice_name)
        await communicate.save(output_file)
        print(f"Successfully created {output_file} using voice {voice_name}")
        return True
    except Exception as e:
        print(f"Failed to use voice {voice_name}: {e}")
        return False

async def main():
    """Main function to test Bengali voices"""
    # Create output directory if it doesn't exist
    output_dir = "Data/voice_samples"
    os.makedirs(output_dir, exist_ok=True)
    
    # Bengali test text
    bengali_text = "আমি বাংলায় কথা বলতে পারি। আমার নাম আদিয়া। আপনি কেমন আছেন?"
    
    # Get all voices
    all_voices = await list_voices()
    print(f"Found {len(all_voices)} total voices")
    
    # Filter Bengali voices
    bengali_voices = await filter_bengali_voices(all_voices)
    print(f"Found {len(bengali_voices)} Bengali voices:")
    
    # Print Bengali voice details
    for i, voice in enumerate(bengali_voices):
        print(f"{i+1}. {voice['ShortName']} - {voice['FriendlyName']}")
    
    # Test each Bengali voice
    successful_voices = []
    for i, voice in enumerate(bengali_voices):
        voice_name = voice["ShortName"]
        output_file = f"{output_dir}/bengali_sample_{i+1}_{voice_name}.mp3"
        
        print(f"\nTesting voice {i+1}/{len(bengali_voices)}: {voice_name}")
        success = await test_voice(voice_name, bengali_text, output_file)
        
        if success:
            successful_voices.append(voice_name)
    
    # Print summary
    print("\n--- SUMMARY ---")
    print(f"Successfully tested {len(successful_voices)}/{len(bengali_voices)} Bengali voices")
    print("Working voices:")
    for i, voice in enumerate(successful_voices):
        print(f"{i+1}. {voice}")
    
    # Update .env with the first successful voice if any
    if successful_voices:
        from dotenv import load_dotenv, set_key
        
        # Load current .env file
        env_path = ".env"
        load_dotenv(env_path)
        
        # Set the first successful Bengali voice
        best_voice = successful_voices[0]
        set_key(env_path, "AssistantVoice", best_voice)
        print(f"\nUpdated .env file to use voice: {best_voice}")

if __name__ == "__main__":
    asyncio.run(main()) 