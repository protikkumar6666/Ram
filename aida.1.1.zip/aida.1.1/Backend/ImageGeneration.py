import asyncio
from random import randint
from PIL import Image
import requests
from dotenv import get_key
import os
from time import sleep
import re

# List of Bengali words related to image generation
bengali_image_words = ["ছবি", "চিত্র", "ফটো", "তৈরি", "দেখাও", "জেনেরেট"]

# Function to open and display images based on a given prompt
def open_images(prompt):
    folder_path = r"Data"  # Folder where the images are stored
    prompt = prompt.replace(" ", "_")  # Replace spaces in prompt with underscores

    # Generate the filenames for the images
    Files = [f"{prompt}{i}.jpg" for i in range(1, 5)]
    
    print(f"Attempting to open {len(Files)} images for prompt: {prompt}")
    opened_count = 0

    for jpg_file in Files:
        image_path = os.path.join(folder_path, jpg_file)

        try:
            # Try to open and display the image
            print(f"Opening image: {image_path}")
            
            # Make sure file exists
            if not os.path.exists(image_path):
                print(f"File does not exist: {image_path}")
                continue
                
            # Different methods to open the image on Windows
            img = Image.open(image_path)
            img.show()
            
            # Alternative method using os.startfile for Windows
            try:
                os.startfile(image_path)
            except AttributeError:
                # os.startfile is only available on Windows
                pass
                
            opened_count += 1
            sleep(1)  # Pause for 1 second before showing the next image

        except Exception as e:
            print(f"Error opening {image_path}: {e}")
    
    print(f"Successfully opened {opened_count} of {len(Files)} images")
    return opened_count > 0

# Function to clean Bengali prompts by removing image-related words
def clean_bengali_prompt(prompt):
    # Remove Bengali image-related words
    for word in bengali_image_words:
        prompt = prompt.replace(word, "")
    
    # Clean up extra spaces
    prompt = re.sub(r'\s+', ' ', prompt).strip()
    
    # If the prompt is too short, use a default
    if len(prompt) < 3:
        return "সুন্দর প্রাকৃতিক দৃশ্য"  # Default: beautiful nature scene
    
    return prompt

# Function to clean English prompts
def clean_english_prompt(prompt):
    # Remove common image generation phrases
    prompt = re.sub(r'generate (an |a |)image (of |about |showing |)', '', prompt, flags=re.IGNORECASE)
    prompt = re.sub(r'create (an |a |)image (of |about |showing |)', '', prompt, flags=re.IGNORECASE)
    prompt = re.sub(r'make (an |a |)image (of |about |showing |)', '', prompt, flags=re.IGNORECASE)
    prompt = re.sub(r'show (me |us |)(an |a |)image (of |about |showing |)', '', prompt, flags=re.IGNORECASE)
    prompt = re.sub(r'draw (an |a |)image (of |about |showing |)', '', prompt, flags=re.IGNORECASE)
    
    # Clean up extra spaces
    prompt = re.sub(r'\s+', ' ', prompt).strip()
    
    # If the prompt is too short, use a default
    if len(prompt) < 3:
        return "beautiful landscape"
    
    return prompt

# Function to extract a good prompt from the raw query
def extract_prompt(raw_query):
    # Check if it's a Bengali query
    is_bengali = any(word in raw_query for word in bengali_image_words)
    
    if is_bengali:
        return clean_bengali_prompt(raw_query)
    else:
        return clean_english_prompt(raw_query)

# API details for the Hugging Face Stable Diffusion model
API_URL = "https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-xl-base-1.0"
headers = {"Authorization": f"Bearer {get_key('.env', 'HuggingFaceAPIKey')}"}

# Async function to send a query to the Hugging Face API
async def query(payload):
    response = await asyncio.to_thread(requests.post, API_URL, headers=headers, json=payload)
    return response.content

# Async function to generate images based on the given prompt
async def generate_images(prompt: str):
    tasks = []

    # Create 4 image generation tasks
    for _ in range(4):
        payload = {
            "inputs": f"{prompt}, quality=4K, sharpness=maximum, Ultra High details, high resolution, seed={randint(0, 1000000)}",
        }
        task = asyncio.create_task(query(payload))
        tasks.append(task)

    # Wait for all tasks to complete
    image_bytes_list = await asyncio.gather(*tasks)

    # Save the generated images to files
    for i, image_bytes in enumerate(image_bytes_list):
        with open(fr"Data\{prompt.replace(' ', '_')}{i + 1}.jpg", "wb") as f:
            f.write(image_bytes)

# Wrapper function to generate and open images
def GenerateImages(prompt: str):
    asyncio.run(generate_images(prompt))  # Run the async image generation
    open_images(prompt)  # Open the generated images

# Main loop to monitor for image generation requests
while True:
    try:
        # Read the status and prompt from the data file
        with open(r"Frontend\Files\ImageGeneration.data", "r") as f:
            Data: str = f.read()

        Prompt, Status = Data.split(",")

        # If the status indicates an image generation request
        if Status == "True":
            print("Generating Images ...")
            print(f"Raw prompt: {Prompt}")
            
            # Process the prompt to extract the actual subject
            actual_prompt = extract_prompt(Prompt)
            print(f"Processed prompt: {actual_prompt}")
            
            # Generate images with the processed prompt
            ImageStatus = GenerateImages(prompt=actual_prompt)

            # Reset the status in the file after generating images
            with open(r"Frontend\Files\ImageGeneration.data", "w") as f:
                f.write("False,False")
                break  # Exit the loop after processing the request

        else:
            sleep(1)  # Wait for 1 second before checking again

    except Exception as e:
        print(f"Error: {e}")
        # Reset status in case of error to avoid getting stuck
        with open(r"Frontend\Files\ImageGeneration.data", "w") as f:
            f.write("False,False")
        sleep(2)  # Wait a bit before trying again or exit
        break